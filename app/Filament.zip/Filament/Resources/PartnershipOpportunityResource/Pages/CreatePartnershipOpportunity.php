<?php

namespace App\Filament\Resources\PartnershipOpportunityResource\Pages;

use App\Filament\Resources\PartnershipOpportunityResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePartnershipOpportunity extends CreateRecord
{
    protected static string $resource = PartnershipOpportunityResource::class;
}
